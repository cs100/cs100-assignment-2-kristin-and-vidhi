#!/bin/sh
#tests single commands

../bin/rshell < single_command_test

