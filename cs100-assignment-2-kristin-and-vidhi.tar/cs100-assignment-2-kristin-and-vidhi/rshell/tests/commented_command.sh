#!/bin/sh

../bin/rshell < commented_command_test

#tests commands with comments