#!/bin/sh
#tests exit and commands with exit

../bin/rshell < exit_test
