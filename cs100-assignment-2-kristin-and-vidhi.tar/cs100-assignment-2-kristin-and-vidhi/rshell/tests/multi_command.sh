#!/bin/sh

#tests commands with ;, &&, or
../bin/rshell < multi_command_test
